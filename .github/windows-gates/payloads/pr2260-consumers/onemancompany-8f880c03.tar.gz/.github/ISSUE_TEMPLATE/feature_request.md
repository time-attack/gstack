---
name: Feature Request
about: Suggest a new feature or improvement
title: "[Feature] "
labels: enhancement
assignees: ''
---

**What problem does this solve?**
A clear description of the problem or use case.

**Proposed solution**
How you'd like it to work.

**Alternatives considered**
Any other approaches you've thought about.

**Additional context**
Anything else — mockups, references, related issues.
